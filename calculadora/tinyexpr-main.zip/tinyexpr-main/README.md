# TinyExpr
This library is a fork of original project with little modification to make work with Arduino.

Original project link - https://github.com/codeplea/tinyexpr
